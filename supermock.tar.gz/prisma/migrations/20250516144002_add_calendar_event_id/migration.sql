-- AlterTable
ALTER TABLE "MockInterview" ADD COLUMN     "calendarEventId" TEXT;

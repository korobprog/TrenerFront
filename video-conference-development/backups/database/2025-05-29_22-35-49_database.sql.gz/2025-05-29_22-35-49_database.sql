--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text,
    refresh_token_expires_in integer
);


ALTER TABLE public."Account" OWNER TO trenerfront_user;

--
-- Name: AdminActionLog; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."AdminActionLog" (
    id text NOT NULL,
    "adminId" text NOT NULL,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    details jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AdminActionLog" OWNER TO trenerfront_user;

--
-- Name: InterviewAssistantCache; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."InterviewAssistantCache" (
    id text NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."InterviewAssistantCache" OWNER TO trenerfront_user;

--
-- Name: InterviewAssistantCompany; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."InterviewAssistantCompany" (
    id integer NOT NULL,
    name text NOT NULL,
    count integer DEFAULT 1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."InterviewAssistantCompany" OWNER TO trenerfront_user;

--
-- Name: InterviewAssistantCompany_id_seq; Type: SEQUENCE; Schema: public; Owner: trenerfront_user
--

CREATE SEQUENCE public."InterviewAssistantCompany_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."InterviewAssistantCompany_id_seq" OWNER TO trenerfront_user;

--
-- Name: InterviewAssistantCompany_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trenerfront_user
--

ALTER SEQUENCE public."InterviewAssistantCompany_id_seq" OWNED BY public."InterviewAssistantCompany".id;


--
-- Name: InterviewAssistantQA; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."InterviewAssistantQA" (
    id text NOT NULL,
    "userId" text NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    category text,
    tags text,
    company text,
    "interviewDate" timestamp(3) without time zone
);


ALTER TABLE public."InterviewAssistantQA" OWNER TO trenerfront_user;

--
-- Name: InterviewAssistantSettings; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."InterviewAssistantSettings" (
    id text NOT NULL,
    "apiKey" text NOT NULL,
    "maxQuestionsPerDay" integer DEFAULT 10 NOT NULL,
    "maxTokensPerQuestion" integer DEFAULT 4000 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "apiType" text DEFAULT 'gemini'::text NOT NULL,
    "langdockAssistantId" text,
    "langdockBaseUrl" text DEFAULT 'https://api.langdock.com/assistant/v1/chat/completions'::text NOT NULL,
    "langdockRegion" text DEFAULT 'eu'::text NOT NULL,
    "geminiApiKey" text,
    "geminiBaseUrl" text DEFAULT 'https://generativelanguage.googleapis.com'::text NOT NULL,
    "geminiModel" text DEFAULT 'gemini-1.5-pro'::text NOT NULL,
    "geminiTemperature" double precision DEFAULT 0.7 NOT NULL,
    "enabledModels" text DEFAULT 'gemini,anthropic,langdock,huggingface'::text NOT NULL,
    "huggingfaceApiKey" text,
    "huggingfaceBaseUrl" text DEFAULT 'https://api-inference.huggingface.co/models'::text NOT NULL,
    "huggingfaceMaxTokens" integer DEFAULT 2000 NOT NULL,
    "huggingfaceModel" text DEFAULT 'mistralai/Mistral-7B-Instruct-v0.2'::text NOT NULL,
    "huggingfaceTemperature" double precision DEFAULT 0.7 NOT NULL,
    "openRouterApiKey" text,
    "openRouterBaseUrl" text DEFAULT 'https://openrouter.ai/api/v1'::text,
    "openRouterMaxTokens" integer DEFAULT 4000,
    "openRouterModel" text DEFAULT 'google/gemma-3-12b-it:free'::text,
    "openRouterTemperature" double precision DEFAULT 0.7
);


ALTER TABLE public."InterviewAssistantSettings" OWNER TO trenerfront_user;

--
-- Name: InterviewAssistantUsage; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."InterviewAssistantUsage" (
    id text NOT NULL,
    "userId" text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "questionsCount" integer DEFAULT 0 NOT NULL,
    "tokensUsed" integer DEFAULT 0 NOT NULL,
    "apiCost" double precision DEFAULT 0 NOT NULL,
    company text,
    "interviewDate" timestamp(3) without time zone
);


ALTER TABLE public."InterviewAssistantUsage" OWNER TO trenerfront_user;

--
-- Name: InterviewFeedback; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."InterviewFeedback" (
    id text NOT NULL,
    "mockInterviewId" text NOT NULL,
    "technicalScore" integer NOT NULL,
    feedback text NOT NULL,
    "isAccepted" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "interviewerRating" integer
);


ALTER TABLE public."InterviewFeedback" OWNER TO trenerfront_user;

--
-- Name: MockInterview; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."MockInterview" (
    id text NOT NULL,
    "interviewerId" text NOT NULL,
    "intervieweeId" text,
    "scheduledTime" timestamp(3) without time zone NOT NULL,
    "meetingLink" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "calendarEventId" text
);


ALTER TABLE public."MockInterview" OWNER TO trenerfront_user;

--
-- Name: PointsTransaction; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."PointsTransaction" (
    id text NOT NULL,
    "userId" text NOT NULL,
    amount integer NOT NULL,
    type text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PointsTransaction" OWNER TO trenerfront_user;

--
-- Name: Question; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."Question" (
    id integer NOT NULL,
    text text NOT NULL,
    category text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    answer text,
    difficulty text,
    "estimatedTime" integer,
    options jsonb,
    question text,
    tags jsonb,
    topic text
);


ALTER TABLE public."Question" OWNER TO trenerfront_user;

--
-- Name: Question_id_seq; Type: SEQUENCE; Schema: public; Owner: trenerfront_user
--

CREATE SEQUENCE public."Question_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Question_id_seq" OWNER TO trenerfront_user;

--
-- Name: Question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trenerfront_user
--

ALTER SEQUENCE public."Question_id_seq" OWNED BY public."Question".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Session" OWNER TO trenerfront_user;

--
-- Name: SystemStatistics; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."SystemStatistics" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "totalUsers" integer DEFAULT 0 NOT NULL,
    "newUsers" integer DEFAULT 0 NOT NULL,
    "totalInterviews" integer DEFAULT 0 NOT NULL,
    "completedInterviews" integer DEFAULT 0 NOT NULL,
    "cancelledInterviews" integer DEFAULT 0 NOT NULL,
    "noShowInterviews" integer DEFAULT 0 NOT NULL,
    "averageTechnicalScore" double precision DEFAULT 0 NOT NULL,
    "totalPointsIssued" integer DEFAULT 0 NOT NULL,
    "totalPointsSpent" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."SystemStatistics" OWNER TO trenerfront_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text,
    email text,
    "emailVerified" timestamp(3) without time zone,
    image text,
    "conductedInterviewsCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isBlocked" boolean DEFAULT false NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    role text DEFAULT 'user'::text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    password text
);


ALTER TABLE public."User" OWNER TO trenerfront_user;

--
-- Name: UserApiSettings; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."UserApiSettings" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "apiKey" text,
    "baseUrl" text,
    "useCustomApi" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "apiType" text DEFAULT 'gemini'::text NOT NULL,
    "langdockApiKey" text,
    "langdockAssistantId" text,
    "langdockBaseUrl" text,
    "geminiApiKey" text,
    "geminiBaseUrl" text,
    "geminiModel" text,
    "geminiTemperature" double precision,
    "huggingfaceApiKey" text,
    "huggingfaceBaseUrl" text DEFAULT 'https://api-inference.huggingface.co/models'::text,
    "huggingfaceMaxTokens" integer DEFAULT 100,
    "huggingfaceModel" text DEFAULT 'distilgpt2'::text,
    "huggingfaceTemperature" double precision DEFAULT 0.7,
    "selectedModel" text,
    "langdockRegion" text DEFAULT 'eu'::text,
    "openRouterApiKey" text,
    "openRouterBaseUrl" text DEFAULT 'https://openrouter.ai/api'::text,
    "openRouterMaxTokens" integer DEFAULT 4000,
    "openRouterModel" text DEFAULT 'google/gemma-3-12b-it:free'::text,
    "openRouterTemperature" double precision DEFAULT 0.7
);


ALTER TABLE public."UserApiSettings" OWNER TO trenerfront_user;

--
-- Name: UserFavoriteQuestion; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."UserFavoriteQuestion" (
    id integer NOT NULL,
    "userId" text NOT NULL,
    "questionId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserFavoriteQuestion" OWNER TO trenerfront_user;

--
-- Name: UserFavoriteQuestion_id_seq; Type: SEQUENCE; Schema: public; Owner: trenerfront_user
--

CREATE SEQUENCE public."UserFavoriteQuestion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserFavoriteQuestion_id_seq" OWNER TO trenerfront_user;

--
-- Name: UserFavoriteQuestion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trenerfront_user
--

ALTER SEQUENCE public."UserFavoriteQuestion_id_seq" OWNED BY public."UserFavoriteQuestion".id;


--
-- Name: UserPoints; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."UserPoints" (
    id text NOT NULL,
    "userId" text NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserPoints" OWNER TO trenerfront_user;

--
-- Name: UserProgress; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."UserProgress" (
    id integer NOT NULL,
    "questionId" integer NOT NULL,
    status text NOT NULL,
    "lastReviewed" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "reviewCount" integer DEFAULT 0 NOT NULL,
    "knownCount" integer DEFAULT 0 NOT NULL,
    "repeatCount" integer DEFAULT 0 NOT NULL,
    "searchCount" integer DEFAULT 0 NOT NULL,
    "unknownCount" integer DEFAULT 0 NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isCorrect" boolean,
    "needsReview" boolean DEFAULT false NOT NULL,
    "timeSpent" integer,
    "lastAnswer" text
);


ALTER TABLE public."UserProgress" OWNER TO trenerfront_user;

--
-- Name: UserProgress_id_seq; Type: SEQUENCE; Schema: public; Owner: trenerfront_user
--

CREATE SEQUENCE public."UserProgress_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."UserProgress_id_seq" OWNER TO trenerfront_user;

--
-- Name: UserProgress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: trenerfront_user
--

ALTER SEQUENCE public."UserProgress_id_seq" OWNED BY public."UserProgress".id;


--
-- Name: UserViolation; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."UserViolation" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."UserViolation" OWNER TO trenerfront_user;

--
-- Name: VerificationToken; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public."VerificationToken" (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."VerificationToken" OWNER TO trenerfront_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: trenerfront_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO trenerfront_user;

--
-- Name: InterviewAssistantCompany id; Type: DEFAULT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantCompany" ALTER COLUMN id SET DEFAULT nextval('public."InterviewAssistantCompany_id_seq"'::regclass);


--
-- Name: Question id; Type: DEFAULT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."Question" ALTER COLUMN id SET DEFAULT nextval('public."Question_id_seq"'::regclass);


--
-- Name: UserFavoriteQuestion id; Type: DEFAULT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserFavoriteQuestion" ALTER COLUMN id SET DEFAULT nextval('public."UserFavoriteQuestion_id_seq"'::regclass);


--
-- Name: UserProgress id; Type: DEFAULT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserProgress" ALTER COLUMN id SET DEFAULT nextval('public."UserProgress_id_seq"'::regclass);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state, refresh_token_expires_in) FROM stdin;
cmb9k4mth0002mkc4i40h8586	cmb9k4mtb0000mkc4b5uwfgtz	oauth	github	62425861	\N	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	\N	bearer	read:user,user:email	\N	\N	\N
\.


--
-- Data for Name: AdminActionLog; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."AdminActionLog" (id, "adminId", action, "entityType", "entityId", details, "createdAt") FROM stdin;
\.


--
-- Data for Name: InterviewAssistantCache; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."InterviewAssistantCache" (id, question, answer, "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: InterviewAssistantCompany; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."InterviewAssistantCompany" (id, name, count, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: InterviewAssistantQA; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."InterviewAssistantQA" (id, "userId", question, answer, "createdAt", category, tags, company, "interviewDate") FROM stdin;
\.


--
-- Data for Name: InterviewAssistantSettings; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."InterviewAssistantSettings" (id, "apiKey", "maxQuestionsPerDay", "maxTokensPerQuestion", "isActive", "apiType", "langdockAssistantId", "langdockBaseUrl", "langdockRegion", "geminiApiKey", "geminiBaseUrl", "geminiModel", "geminiTemperature", "enabledModels", "huggingfaceApiKey", "huggingfaceBaseUrl", "huggingfaceMaxTokens", "huggingfaceModel", "huggingfaceTemperature", "openRouterApiKey", "openRouterBaseUrl", "openRouterMaxTokens", "openRouterModel", "openRouterTemperature") FROM stdin;
\.


--
-- Data for Name: InterviewAssistantUsage; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."InterviewAssistantUsage" (id, "userId", date, "questionsCount", "tokensUsed", "apiCost", company, "interviewDate") FROM stdin;
\.


--
-- Data for Name: InterviewFeedback; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."InterviewFeedback" (id, "mockInterviewId", "technicalScore", feedback, "isAccepted", "createdAt", "updatedAt", "interviewerRating") FROM stdin;
\.


--
-- Data for Name: MockInterview; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."MockInterview" (id, "interviewerId", "intervieweeId", "scheduledTime", "meetingLink", status, "createdAt", "updatedAt", "calendarEventId") FROM stdin;
\.


--
-- Data for Name: PointsTransaction; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."PointsTransaction" (id, "userId", amount, type, description, "createdAt") FROM stdin;
\.


--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."Question" (id, text, category, "createdAt", answer, difficulty, "estimatedTime", options, question, tags, topic) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: SystemStatistics; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."SystemStatistics" (id, date, "totalUsers", "newUsers", "totalInterviews", "completedInterviews", "cancelledInterviews", "noShowInterviews", "averageTechnicalScore", "totalPointsIssued", "totalPointsSpent") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."User" (id, name, email, "emailVerified", image, "conductedInterviewsCount", "createdAt", "isBlocked", "lastLoginAt", role, "updatedAt", password) FROM stdin;
default-user	Default User	default@example.com	\N	\N	0	2025-05-29 14:50:14.442	f	\N	user	2025-05-29 14:50:14.442	\N
cmb9k4mtb0000mkc4b5uwfgtz	Maxim Korobkov	korobprog@gmail.com	\N	https://avatars.githubusercontent.com/u/62425861?v=4	0	2025-05-29 15:56:59.903	f	\N	user	2025-05-29 15:56:59.903	\N
\.


--
-- Data for Name: UserApiSettings; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."UserApiSettings" (id, "userId", "apiKey", "baseUrl", "useCustomApi", "createdAt", "updatedAt", "apiType", "langdockApiKey", "langdockAssistantId", "langdockBaseUrl", "geminiApiKey", "geminiBaseUrl", "geminiModel", "geminiTemperature", "huggingfaceApiKey", "huggingfaceBaseUrl", "huggingfaceMaxTokens", "huggingfaceModel", "huggingfaceTemperature", "selectedModel", "langdockRegion", "openRouterApiKey", "openRouterBaseUrl", "openRouterMaxTokens", "openRouterModel", "openRouterTemperature") FROM stdin;
cmb9lff4t0004mkc4jxe5km2z	cmb9k4mtb0000mkc4b5uwfgtz	\N	https://api.anthropic.com	t	2025-05-29 16:33:22.781	2025-05-29 16:35:26.979	openrouter	\N	\N	https://api.langdock.com/assistant/v1/chat/completions	\N	https://generativelanguage.googleapis.com	gemini-1.5-pro	0.7	\N	https://api-inference.huggingface.co/models	4000	meta-llama/Llama-2-7b-chat-hf	0.7	\N	eu	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	https://openrouter.ai/api/v1	4000	google/gemma-3-12b-it:free	0.7
\.


--
-- Data for Name: UserFavoriteQuestion; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."UserFavoriteQuestion" (id, "userId", "questionId", "createdAt") FROM stdin;
\.


--
-- Data for Name: UserPoints; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."UserPoints" (id, "userId", points, "createdAt", "updatedAt") FROM stdin;
cmb9kcq0r0001mkvj4t0iniyp	default-user	0	2025-05-29 16:03:17.307	2025-05-29 16:03:17.307
cmb9ke1s90001mk6rs2hrmi4u	cmb9k4mtb0000mkc4b5uwfgtz	0	2025-05-29 16:04:19.209	2025-05-29 16:04:19.209
\.


--
-- Data for Name: UserProgress; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."UserProgress" (id, "questionId", status, "lastReviewed", "reviewCount", "knownCount", "repeatCount", "searchCount", "unknownCount", "userId", "createdAt", "isCorrect", "needsReview", "timeSpent", "lastAnswer") FROM stdin;
\.


--
-- Data for Name: UserViolation; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."UserViolation" (id, "userId", type, description, "createdAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: VerificationToken; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public."VerificationToken" (identifier, token, expires) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: trenerfront_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
43ceecb2-53bb-4d99-822b-c2ebc52b787a	a79fb31e90b22e025c598cff5963876c339b275ad5fbfb8c15e6693845343004	2025-05-29 14:50:14.356348+00	20250516064942_init	\N	\N	2025-05-29 14:50:14.337386+00	1
784b7f0b-6ef9-4825-974a-6edc4d34fbb2	72f680cbddc178777f432eb4a2be89a5b1c1ce27d1c91edd1ea44e8ae3937f2f	2025-05-29 14:50:14.572333+00	20250520002945_add_gemini_api_support	\N	\N	2025-05-29 14:50:14.563753+00	1
d825383c-3127-4993-9457-93232855dabf	f46d40ae1a3d449100b5d15314beb71acea583709d85804c59ffd48562bf2442	2025-05-29 14:50:14.362749+00	20250516071204_add_detailed_statistics	\N	\N	2025-05-29 14:50:14.357313+00	1
89a2a354-095e-415a-9700-f3c286022f57	0184271d1ae25febfb404065d9aa31c7c35b6d1fb86451b5d7cda640cbd6c5cb	2025-05-29 14:50:14.394657+00	20250516075745_add_auth	\N	\N	2025-05-29 14:50:14.363605+00	1
d84b478e-eb73-4cfb-b708-43e95f47010f	47aefc7d45bfd4b0d552f2ba85a7fe98b2479cf7569931795c84a1ed1dccb06f	2025-05-29 14:50:14.672777+00	20250527075716_add_training_fields	\N	\N	2025-05-29 14:50:14.655496+00	1
5b9411b0-1bef-412c-b392-62967208fd5f	455579a57ab2dfae3a1b3b58e0055cfed807321c5e16f396babe0e8da7299175	2025-05-29 14:50:14.416643+00	20250516105845_add_mock_interviews	\N	\N	2025-05-29 14:50:14.395562+00	1
8891930a-7bf0-4043-99b9-f3c71f26a596	7ad2b8a2da6e6fdbac209eebc5bbc7f734a87b22d325e413a66ce5526fef13b8	2025-05-29 14:50:14.583494+00	20250520031729_add_huggingface_max_tokens	\N	\N	2025-05-29 14:50:14.574979+00	1
f12cdc7c-5e60-46ad-8157-1d71f9ddcab4	e0b29b90b6fc9e0aa69df92b80c94bf4dfebffb1a8c8cfafe9946df4f1417425	2025-05-29 14:50:14.423749+00	20250516144002_add_calendar_event_id	\N	\N	2025-05-29 14:50:14.41902+00	1
577d931e-026a-4356-84e0-b69ad7c97158	a1826dd8fd3259300099014c76f8e3ad38c0178543082420cb6d0d20b7543241	2025-05-29 14:50:14.438752+00	20250517002304_add_points_transactions	\N	\N	2025-05-29 14:50:14.424604+00	1
edf8edbe-e1bd-42f1-8221-da1f7374323f	69373095c7f50414a94fb9e3f3a7485bfa9e0d6940214d87358a92322b7ea93d	2025-05-29 14:50:14.457091+00	20250517012343_add_admin_panel_support	\N	\N	2025-05-29 14:50:14.440231+00	1
89ad12f5-6f89-471e-b98d-933410a788fa	c149fffdf92ab098ef8dac73d49b913f7295a5518376b1f7da9133c651ddbc40	2025-05-29 14:50:14.597166+00	20250520033036_add_huggingface_api_fields	\N	\N	2025-05-29 14:50:14.585328+00	1
30194a9b-3cb6-49e9-95c3-5189dfa532ac	dca8940add97f3bac8cb0da66c55c0e5e6ddecbf94466b455bc18eda744c46c4	2025-05-29 14:50:14.461694+00	20250517012449_	\N	\N	2025-05-29 14:50:14.458271+00	1
4a377013-1d39-40f2-b78f-8f7be1cf1f55	ab80a534dfa4779eeae4ae5aeac192eea19b283671d6083c8f112e3c8a4229df	2025-05-29 14:50:14.47602+00	20250517231706_add_superadmin_support	\N	\N	2025-05-29 14:50:14.46294+00	1
a3035d16-9456-4466-9094-df27d8b7cf24	addc2abc66a6cee8ed8aa267655117587643947cc8b7c41f1c79ed485955c0ba	2025-05-29 14:50:14.482891+00	20250518094030_add_refresh_token_expires_in	\N	\N	2025-05-29 14:50:14.478013+00	1
4bd6925b-6653-47e6-906b-db49824d37f2	5aa82c2b821f2d86648c095b9a030c02fb80039543d49bc6522aae0274f0d3e1	2025-05-29 14:50:14.607165+00	20250520040912_make_huggingface_fields_optional	\N	\N	2025-05-29 14:50:14.59886+00	1
22cfc845-ef35-42f2-9394-936ea9569e54	81d6055f6f0bbbbee80b739356fd955a4922c2afdc634f79917bc6c56b6c244f	2025-05-29 14:50:14.519358+00	20250519014745_add_interview_date_to_usage	\N	\N	2025-05-29 14:50:14.484807+00	1
29c29ab6-2b2f-4448-a34e-e6208368b14d	5342668156c646ca3a80a276f98be6b7b2b7d599b34190d9f1b0760d3290fdd4	2025-05-29 14:50:14.547885+00	20250519022643_add_user_api_settings	\N	\N	2025-05-29 14:50:14.521939+00	1
65038868-d178-4548-aba8-039e0f1f8d51	02de460fa8ff6656206b3a6c024a25b77e3e43a30109ecc2602f1f6821db0866	2025-05-29 14:50:14.678383+00	20250527084059_add_last_answer_field	\N	\N	2025-05-29 14:50:14.674454+00	1
bc4f46a5-5b60-4c7d-8b84-ccb6096f2e86	8ad0d4e3d7d0ecb52ce54d87e459b59c3fa39706b8efae067eff013d617866b1	2025-05-29 14:50:14.560459+00	20250519040738_add_langdock_fields_to_user_api_settings	\N	\N	2025-05-29 14:50:14.550125+00	1
61e45098-18b3-484e-96e4-890f5546de91	1219157ca2625cc0ecebc0fad4178a50a95f61b3beb0e645afac26cdffc8c777	2025-05-29 14:50:14.617241+00	20250520065953_add_langdock_region	\N	\N	2025-05-29 14:50:14.609381+00	1
472ee047-2139-4e9f-97f6-2c2434dacbd7	122d743a0403e77ad7e0ed9447f5b8826f2fbdbc55612d936eff004dd13c2eec	2025-05-29 14:50:14.63565+00	20250520070358_add_langdock_region	\N	\N	2025-05-29 14:50:14.62272+00	1
6d52e739-d7c1-441c-8135-3c2272af0172	d0ccb1aacb1ec3a69a1885b295b21ad3904728a957f6f0ef124cbd45ce3577f3	2025-05-29 14:50:14.645164+00	20250520072529_add_openrouter_support	\N	\N	2025-05-29 14:50:14.637632+00	1
633213e6-d4f4-4270-972e-78d3b34dda03	8cd10f0fabc8af4e27681dbf5cecd6c0f2bae7e6b34feba839bb931712023c4a	2025-05-29 14:50:14.653928+00	20250520120349_add_openrouter_to_interview_assistant_settings	\N	\N	2025-05-29 14:50:14.647242+00	1
\.


--
-- Name: InterviewAssistantCompany_id_seq; Type: SEQUENCE SET; Schema: public; Owner: trenerfront_user
--

SELECT pg_catalog.setval('public."InterviewAssistantCompany_id_seq"', 1, false);


--
-- Name: Question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: trenerfront_user
--

SELECT pg_catalog.setval('public."Question_id_seq"', 1, false);


--
-- Name: UserFavoriteQuestion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: trenerfront_user
--

SELECT pg_catalog.setval('public."UserFavoriteQuestion_id_seq"', 1, false);


--
-- Name: UserProgress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: trenerfront_user
--

SELECT pg_catalog.setval('public."UserProgress_id_seq"', 1, false);


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: AdminActionLog AdminActionLog_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."AdminActionLog"
    ADD CONSTRAINT "AdminActionLog_pkey" PRIMARY KEY (id);


--
-- Name: InterviewAssistantCache InterviewAssistantCache_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantCache"
    ADD CONSTRAINT "InterviewAssistantCache_pkey" PRIMARY KEY (id);


--
-- Name: InterviewAssistantCompany InterviewAssistantCompany_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantCompany"
    ADD CONSTRAINT "InterviewAssistantCompany_pkey" PRIMARY KEY (id);


--
-- Name: InterviewAssistantQA InterviewAssistantQA_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantQA"
    ADD CONSTRAINT "InterviewAssistantQA_pkey" PRIMARY KEY (id);


--
-- Name: InterviewAssistantSettings InterviewAssistantSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantSettings"
    ADD CONSTRAINT "InterviewAssistantSettings_pkey" PRIMARY KEY (id);


--
-- Name: InterviewAssistantUsage InterviewAssistantUsage_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantUsage"
    ADD CONSTRAINT "InterviewAssistantUsage_pkey" PRIMARY KEY (id);


--
-- Name: InterviewFeedback InterviewFeedback_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewFeedback"
    ADD CONSTRAINT "InterviewFeedback_pkey" PRIMARY KEY (id);


--
-- Name: MockInterview MockInterview_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."MockInterview"
    ADD CONSTRAINT "MockInterview_pkey" PRIMARY KEY (id);


--
-- Name: PointsTransaction PointsTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."PointsTransaction"
    ADD CONSTRAINT "PointsTransaction_pkey" PRIMARY KEY (id);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SystemStatistics SystemStatistics_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."SystemStatistics"
    ADD CONSTRAINT "SystemStatistics_pkey" PRIMARY KEY (id);


--
-- Name: UserApiSettings UserApiSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserApiSettings"
    ADD CONSTRAINT "UserApiSettings_pkey" PRIMARY KEY (id);


--
-- Name: UserFavoriteQuestion UserFavoriteQuestion_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserFavoriteQuestion"
    ADD CONSTRAINT "UserFavoriteQuestion_pkey" PRIMARY KEY (id);


--
-- Name: UserPoints UserPoints_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserPoints"
    ADD CONSTRAINT "UserPoints_pkey" PRIMARY KEY (id);


--
-- Name: UserProgress UserProgress_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserProgress"
    ADD CONSTRAINT "UserProgress_pkey" PRIMARY KEY (id);


--
-- Name: UserViolation UserViolation_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserViolation"
    ADD CONSTRAINT "UserViolation_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: InterviewAssistantCompany_name_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "InterviewAssistantCompany_name_key" ON public."InterviewAssistantCompany" USING btree (name);


--
-- Name: InterviewFeedback_mockInterviewId_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "InterviewFeedback_mockInterviewId_key" ON public."InterviewFeedback" USING btree ("mockInterviewId");


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: SystemStatistics_date_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "SystemStatistics_date_key" ON public."SystemStatistics" USING btree (date);


--
-- Name: UserApiSettings_userId_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "UserApiSettings_userId_key" ON public."UserApiSettings" USING btree ("userId");


--
-- Name: UserFavoriteQuestion_userId_questionId_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "UserFavoriteQuestion_userId_questionId_key" ON public."UserFavoriteQuestion" USING btree ("userId", "questionId");


--
-- Name: UserPoints_userId_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "UserPoints_userId_key" ON public."UserPoints" USING btree ("userId");


--
-- Name: UserProgress_questionId_userId_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "UserProgress_questionId_userId_key" ON public."UserProgress" USING btree ("questionId", "userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: VerificationToken_identifier_token_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "VerificationToken_identifier_token_key" ON public."VerificationToken" USING btree (identifier, token);


--
-- Name: VerificationToken_token_key; Type: INDEX; Schema: public; Owner: trenerfront_user
--

CREATE UNIQUE INDEX "VerificationToken_token_key" ON public."VerificationToken" USING btree (token);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AdminActionLog AdminActionLog_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."AdminActionLog"
    ADD CONSTRAINT "AdminActionLog_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InterviewAssistantQA InterviewAssistantQA_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantQA"
    ADD CONSTRAINT "InterviewAssistantQA_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InterviewAssistantUsage InterviewAssistantUsage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewAssistantUsage"
    ADD CONSTRAINT "InterviewAssistantUsage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: InterviewFeedback InterviewFeedback_mockInterviewId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."InterviewFeedback"
    ADD CONSTRAINT "InterviewFeedback_mockInterviewId_fkey" FOREIGN KEY ("mockInterviewId") REFERENCES public."MockInterview"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MockInterview MockInterview_intervieweeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."MockInterview"
    ADD CONSTRAINT "MockInterview_intervieweeId_fkey" FOREIGN KEY ("intervieweeId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MockInterview MockInterview_interviewerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."MockInterview"
    ADD CONSTRAINT "MockInterview_interviewerId_fkey" FOREIGN KEY ("interviewerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PointsTransaction PointsTransaction_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."PointsTransaction"
    ADD CONSTRAINT "PointsTransaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserApiSettings UserApiSettings_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserApiSettings"
    ADD CONSTRAINT "UserApiSettings_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserFavoriteQuestion UserFavoriteQuestion_questionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserFavoriteQuestion"
    ADD CONSTRAINT "UserFavoriteQuestion_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES public."Question"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserFavoriteQuestion UserFavoriteQuestion_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserFavoriteQuestion"
    ADD CONSTRAINT "UserFavoriteQuestion_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserPoints UserPoints_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserPoints"
    ADD CONSTRAINT "UserPoints_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserProgress UserProgress_questionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserProgress"
    ADD CONSTRAINT "UserProgress_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES public."Question"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserProgress UserProgress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserProgress"
    ADD CONSTRAINT "UserProgress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserViolation UserViolation_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trenerfront_user
--

ALTER TABLE ONLY public."UserViolation"
    ADD CONSTRAINT "UserViolation_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

